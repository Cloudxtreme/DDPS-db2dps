/*****************************************************************************\
 *                              CLASSNAME
\*****************************************************************************/

/*! @file 
 *
 *  @brief
 *  Kurzbeschreibung
 *
 *  Ausfuehrliche Beschreibung .. Beispiele findet man in example-comments.cpp
 *
 *  @author XX
 *  
 *  @flags
 *  - @c YY - compiles without ..
 *  
 */


/** @class CLASSNAME
 *
 * Kurzbeschreibung.
 *
 * Detaillierte Beschreibung ...
 *
 * @see
 *   ...
 *
 * @todo
 *   Was man noch tun muss ..
 *
 * @implementation
 *   Implementierungsdetails, etc.
 *
 * @bug
 *   ...
 *
 **/


//---------------------------------------------------------------------------
//  Includes
//---------------------------------------------------------------------------


#include <stdlib.h>
#include <stdio.h>
#include <iostream>

#include <CLASSNAME.h>

namespace NAMESPACE {


//**************************************************************************
// CLASSNAME
//**************************************************************************

//---------------------------------------------------------------------------
//  Public Instance Methods
//---------------------------------------------------------------------------


// --------------------------------------------------------------------------
// @name             Creation, desctruction, assignments
// @{


CLASSNAME::CLASSNAME()
:	PARENTCLASS(),
	// TODO: initialize members
{
}


//CLASSNAME::CLASSNAME( const CLASSNAME &source )
//: PARENTCLASS( source ),
//	// TODO: initialize members
//{
//}


CLASSNAME::~CLASSNAME() throw()
{
}


void CLASSNAME::operator = ( const CLASSNAME &source )
// const CLASSNAME & CLASSNAME::operator = ( const CLASSNAME &source )
{
	if ( this == &source )
		return;

	// copy parts inherited from parent
	*( static_cast<PARENTCLASS*>(this) ) = source;

	// free mem alloced by members of 'this'

	// alloc new mem for members

	// copy 
	// return *this;
}


// --------------------------------------------------------------------------
// @}
// @name                       Comparison
// @{


bool CLASSNAME::operator == ( const CLASSNAME &other ) const
{
}


bool CLASSNAME::operator != ( const CLASSNAME &other ) const
{
	return ! (*this == other);
}


// --------------------------------------------------------------------------
// @}
// @name                       Access
// @{



// --------------------------------------------------------------------------
// @}
// @name                       Properties
// @{



// --------------------------------------------------------------------------
// @}
// @name                       Your Category
// @{



// @}
// --------------------------------------------------------------------------


//---------------------------------------------------------------------------
//  Private/Protected Instance Methods
//---------------------------------------------------------------------------

//---------------------------------------------------------------------------
//  Class methods and variables
//---------------------------------------------------------------------------




#pragma set woff 1174
char CLASSNAME::cvsid[] =
"@(#)$Id$";
#pragma reset woff 1174



/**  Zum Abpasten fuer eine Funktion, Methode, oder Makro-"Funktion".
 *
 * @param param1	Comment for param1
 *
 * @return
 *   Text for return value.
 *
 * Detaillierte Beschreibung ...
 *
 * @throw Exception
 *   Beschreibung ..
 *
 * @warning
 *   Dinge, die der Aufrufer unbedingt beachten muss...
 *
 * @pre
 *   Annahmnen, die die Funktion macht...
 *
 * @sideeffects
 *   Nebenwirkungen, globale Variablen, die veraendert werden, ..
 *
 * @todo
 *   Was noch getan werden muss
 *
 * @bug
 *   Bekannte Bugs dieser Funktion
 *
 * @see
 *   ...
 *
 * @implementation
 *   Implementierungsdetails, TODOs, ...
 *
 **/


} // namespace NAMESPACE


